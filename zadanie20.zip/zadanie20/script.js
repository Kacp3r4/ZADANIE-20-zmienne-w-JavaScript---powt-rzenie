function sumaSrednia() {
    let a = Number(a1.value);
    let b = Number(a2.value);
    let c = Number(a3.value);

    let suma = a + b + c;
    let srednia = suma / 3;

    wynik1.innerHTML = "Suma: " + suma + "<br>Średnia: " + srednia;
}

function operacje() {
    let a = Number(b1.value);
    let b = Number(b2.value);

    wynik2.innerHTML =
        "Suma: " + (a + b) + "<br>" +
        "Różnica: " + (a - b) + "<br>" +
        "Iloczyn: " + (a * b);
}

function pierwiastek() {
    let a = Number(c1.value);
    wynik3.innerHTML = "Pierwiastek: " + Math.sqrt(a);
}

function kwadrat() {
    let a = Number(d1.value);
    wynik4.innerHTML = "Pole: " + (a * a);
}

function prostopadloscian() {
    let a = Number(e1.value);
    let b = Number(e2.value);
    let c = Number(e3.value);

    let pole = 2 * (a*b + a*c + b*c);
    wynik5.innerHTML = "Pole: " + pole;
}

function kolo() {
    let r = Number(f1.value);

    let pole = Math.PI * r * r;
    let obwod = 2 * Math.PI * r;

    wynik6.innerHTML =
        "Pole: " + pole.toFixed(2) + "<br>" +
        "Obwód: " + obwod.toFixed(2);
}

function paliwoStale() {
    let cena = Number(g1.value);
    let koszt = (360 / 100) * 8 * cena;

    wynik7.innerHTML = "Koszt: " + koszt.toFixed(2) + " zł";
}

function paliwoDowolne() {
    let cena = Number(h1.value);
    let km = Number(h2.value);
    let spalanie = Number(h3.value);

    let koszt = (km / 100) * spalanie * cena;

    wynik8.innerHTML = "Koszt: " + koszt.toFixed(2) + " zł";
}

function lokata() {
    let kwota = Number(i1.value);

    let zyskBrutto = kwota * 0.08;
    let podatek = zyskBrutto * 0.19;
    let zyskNetto = zyskBrutto - podatek;

    wynik9.innerHTML =
        "Zysk netto: " + zyskNetto.toFixed(2) + " zł<br>" +
        "Kwota końcowa: " + (kwota + zyskNetto).toFixed(2) + " zł";
}